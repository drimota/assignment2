package weatherapp;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.util.concurrent.CompletionException;

public class MainController {
    @FXML
    private TextField cityInput;

    @FXML
    private TextArea weatherOutput;

    public void getWeather() {
        String city = cityInput.getText();
        String apiKey = "1ec29a2c49652b53ed9bda24afefd098";
        String url = String.format("https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s", city, apiKey);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .thenAccept(this::parseJson)
                .exceptionally(e -> {
                    if (e.getCause() instanceof HttpTimeoutException) {
                        weatherOutput.setText("Request timed out. Please try again.");
                    } else if (e.getCause() instanceof CompletionException) {
                        weatherOutput.setText("Invalid city name. Please try again.");
                    } else {
                        weatherOutput.setText("An error occurred: " + e.getMessage());
                    }
                    return null;
                });
    }

    private <Gson> void parseJson(String responseBody) {
        Gson gson = new Gson();
        weatherapp.WeatherData weatherData = gson.clone(responseBody, weatherapp.WeatherData.class);
        double tempInCelsius = weatherData.getMain().getTemp() - 273.15;
        String result = String.format("City: %s\nTemperature: %.2f°C", weatherData.getName(), tempInCelsius);
        weatherOutput.setText(result);
    }
}
